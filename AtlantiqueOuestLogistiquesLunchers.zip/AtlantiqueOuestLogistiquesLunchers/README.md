# Atlantique Ouest Logistiques Lunchers

Launcher WPF (.NET 8) pour Euro Truck Simulator 2.

## Ouvrir le projet

1. Installe **.NET 8 SDK** si ce n'est pas déjà fait : https://dotnet.microsoft.com/download
2. Ouvre `AtlantiqueOuestLogistiquesLunchers.csproj` directement avec Visual Studio 2022
   (menu Fichier > Ouvrir > Projet/Solution).
3. Compile (Ctrl+Maj+B) puis lance (F5).

## Avant de lancer

Édite `appsettings.json` (à la racine du projet) :

- `DossierMods` : dossier où sont installés les mods (par défaut `Documents\Euro Truck Simulator 2\mod`)
- `CheminConfigCfg` : chemin vers `config.cfg`
- `CheminExeJeu` : chemin vers `eurotrucks2.exe` (à adapter selon où Steam a installé le jeu)
- `UrlManifest` : URL vers ton fichier `manifest.json` (liste des mods attendus)
- `UrlArchiveComplete` : URL vers l'archive zip complète des mods
- `UrlSteamWorkshop` : lien vers ta collection Steam Workshop

⚠️ **`UrlManifest` et `UrlArchiveComplete` sont vides pour l'instant** (hébergement pas encore choisi).
Tant qu'ils ne pointent pas vers de vraies URLs, le bouton "Télécharger / Vérifier les mods" plantera.
Utilise `manifest.example.json` comme modèle pour le format attendu.

## Vérifier les clés du config.cfg

Le fichier `Services/ConfigService.cs` cherche les lignes `uset g_convoy_size` et
`uset g_buffer_size`. Ouvre ton propre `config.cfg` (Bloc-notes) et vérifie que
ces noms de clés correspondent bien à ta version du jeu — sinon adapte le code.

## Rendre le launcher téléchargeable (un seul .exe)

Un profil de publication est déjà configuré dans le projet. Pour générer un `.exe` autonome
que tes joueurs pourront télécharger et lancer sans installer Visual Studio ni le SDK .NET :

1. Dans Visual Studio : clic droit sur le projet **AtlantiqueOuestLogistiquesLunchers**
   dans l'Explorateur de solutions → **Publier...**
2. Choisis **Dossier** comme cible, puis **Suivant** jusqu'à la fin (le profil déjà
   configuré — Windows x64, autonome, fichier unique — sera proposé automatiquement)
3. Clique sur **Publier**
4. Le fichier `.exe` (et `appsettings.json` à côté) se trouve dans :
   `bin\Release\net8.0-windows\publish\`
5. Zippe ce dossier (ou juste `AtlantiqueOuestLogistiquesLunchers.exe` +
   `appsettings.json`) et partage-le où tu veux (Discord, Google Drive, GitHub, etc.)

⚠️ Le `.exe` fait plusieurs dizaines de Mo car il embarque le runtime .NET (c'est ce
qui permet à tes joueurs de le lancer sans rien installer). N'oublie pas de mettre à
jour `appsettings.json` avec tes vraies URLs avant de publier.

## Statut serveur en temps réel

Le panneau "SERVEUR DÉDIÉ AOL" interroge ton serveur dédié ETS2 toutes les 20 secondes
via le protocole standard **A2S_INFO** (le même que les serveurs Source/Steam), directement
sur l'IP et le port de requête du serveur — **pas** via le panel fly-serv.com, qui bloque les
accès automatisés et nécessite une connexion.

Renseigne dans `appsettings.json` :
- `ServeurIp` : l'adresse IP publique de ton serveur dédié
- `ServeurPortQuery` : le port de requête (`query_dedicated_port` dans `server_config.sii`,
  27016 par défaut)

Ces deux infos sont normalement visibles dans ton panel d'hébergement fly-serv.com
(section "connexion" ou "ports" du serveur) ou dans le fichier `server_config.sii` généré
par ETS2 sur ta machine hôte.

## Logo

Déjà intégré (`Assets/logo.png`) — utilisé dans la barre latérale, en icône de fenêtre/barre
des tâches, et comme icône de l'exécutable (`Assets/app.ico`).

## Structure

```
MainWindow.xaml(.cs)              → fenêtre principale, menu latéral, navigation
Views/
  LancementTelechargementView     → onglet 1 : les 3 boutons (mods, workshop, lancer)
  OrdreModView                    → onglet 2 : squelette à compléter
  CarteInteractiveView            → onglet 3 : squelette à compléter
  NotreHistoireView               → onglet 4 : squelette à compléter
  ConseilAidesView                → onglet 5 : squelette à compléter
Services/
  ConfigService                   → modifie config.cfg
  ModManagerService                → scan + téléchargement des mods
  GameLauncherService              → lance le jeu
Models/
  ModManifestEntry, EtapeLauncher
appsettings.json                  → chemins et URLs (à adapter)
manifest.example.json             → format attendu du manifest de mods
```

## Prochaines étapes possibles

- Définir l'hébergement des mods (serveur perso, GitHub Releases, etc.)
- Générer les vrais hash SHA-256 des mods pour le manifest
- Construire l'onglet "Ordre des mods" (liste réordonnable, glisser-déposer)
- Construire l'onglet "Carte interactive"
