using System.Windows;

namespace AtlantiqueOuestLogistiquesLunchers
{
    public partial class App : Application
    {
    }
}
