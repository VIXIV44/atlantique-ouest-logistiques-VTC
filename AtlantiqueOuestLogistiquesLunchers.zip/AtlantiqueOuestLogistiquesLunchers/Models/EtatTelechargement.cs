namespace AtlantiqueOuestLogistiquesLunchers.Models
{
    /// <summary>
    /// État de progression d'une opération longue (téléchargement, extraction).
    /// Pourcentage = null quand la taille totale est inconnue (barre indéterminée).
    /// </summary>
    public class EtatTelechargement
    {
        public string Message { get; set; } = string.Empty;
        public double? Pourcentage { get; set; }
    }
}
