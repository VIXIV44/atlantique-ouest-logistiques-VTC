using System.Windows.Controls;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public partial class CarteInteractiveView : UserControl
    {
        public CarteInteractiveView()
        {
            InitializeComponent();
        }
    }
}
