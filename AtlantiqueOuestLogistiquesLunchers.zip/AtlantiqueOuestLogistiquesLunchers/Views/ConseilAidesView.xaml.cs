using System.Windows.Controls;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public partial class ConseilAidesView : UserControl
    {
        public ConseilAidesView()
        {
            InitializeComponent();
        }
    }
}
