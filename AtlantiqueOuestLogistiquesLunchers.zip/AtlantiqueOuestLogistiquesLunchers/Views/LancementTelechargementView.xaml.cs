using System;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using AtlantiqueOuestLogistiquesLunchers.Models;
using AtlantiqueOuestLogistiquesLunchers.Services;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public partial class LancementTelechargementView : UserControl
    {
        private readonly ModManagerService _modManagerService;
        private readonly GameLauncherService _gameLauncherService;
        private readonly ServerStatusService _serverStatusService;
        private readonly AppSettings _settings;
        private readonly DispatcherTimer _timerStatutServeur;

        public LancementTelechargementView()
        {
            InitializeComponent();

            _settings = AppSettings.Charger();

            var configService = new ConfigService(_settings.CheminConfigCfg);
            _modManagerService = new ModManagerService(
                _settings.DossierMods,
                _settings.UrlManifest,
                _settings.UrlArchiveComplete);
            _gameLauncherService = new GameLauncherService(_settings.CheminExeJeu, configService);
            _serverStatusService = new ServerStatusService(_settings.ServeurIp, _settings.ServeurPortQuery);

            // Vérifie le statut du serveur dédié tout de suite, puis toutes les 20 secondes
            _ = RafraichirStatutServeurAsync();
            _timerStatutServeur = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
            _timerStatutServeur.Tick += async (s, e) => await RafraichirStatutServeurAsync();
            _timerStatutServeur.Start();

            Unloaded += (s, e) => _timerStatutServeur.Stop();
        }

        private async Task RafraichirStatutServeurAsync()
        {
            var statut = await _serverStatusService.InterrogerAsync();

            if (statut.EnLigne)
            {
                TxtStatutServeur.Text = $"🟢 EN LIGNE — {statut.NombreJoueurs}/{statut.JoueursMax} joueurs";
                TxtStatutServeur.Foreground = (System.Windows.Media.Brush)FindResource("CouleurVert");
                BordureStatutServeur.BorderBrush = (System.Windows.Media.Brush)FindResource("CouleurVert");
                BordureStatutServeur.Background = new SolidColorBrush(Color.FromRgb(0x0E, 0x2A, 0x1E));
            }
            else
            {
                TxtStatutServeur.Text = "⚡ HORS LIGNE / MAINTENANCE";
                TxtStatutServeur.Foreground = (System.Windows.Media.Brush)FindResource("CouleurRouge");
                BordureStatutServeur.BorderBrush = (System.Windows.Media.Brush)FindResource("CouleurRouge");
                BordureStatutServeur.Background = new SolidColorBrush(Color.FromRgb(0x2A, 0x14, 0x14));
            }
        }

        /// <summary>
        /// Un seul clic : synchronise les mods (scan + téléchargement si besoin),
        /// applique la config, puis lance le jeu.
        /// </summary>
        private async void BtnLancerJeu_Click(object sender, RoutedEventArgs e)
        {
            BtnLancerJeu.IsEnabled = false;
            ConteneurBarreProgression.Visibility = Visibility.Visible;
            BarreProgression.Width = 0;

            var progression = (IProgress<EtatTelechargement>)new Progress<EtatTelechargement>(etat =>
            {
                TxtStatut.Text = etat.Message;

                if (etat.Pourcentage.HasValue)
                {
                    double largeurMax = ConteneurBarreProgression.ActualWidth;
                    BarreProgression.Width = largeurMax * (etat.Pourcentage.Value / 100.0);
                }
            });

            try
            {
                if (string.IsNullOrWhiteSpace(_settings.UrlManifest))
                {
                    if (await _modManagerService.ModsDejaAJourAsync())
                    {
                        progression.Report(new EtatTelechargement { Message = "Mods déjà à jour, aucun téléchargement nécessaire.", Pourcentage = 100 });
                    }
                    else
                    {
                        // Pas de manifest configuré : on télécharge systématiquement
                        // l'archive complète et on remplace tout.
                        await _modManagerService.RemplacerParArchiveCompleteAsync(progression);
                    }
                }
                else
                {
                    var manquants = await _modManagerService.ScannerModsManquantsAsync();
                    await _modManagerService.SynchroniserModsAsync(manquants, progression);
                }

                TxtStatut.Text = "Mods synchronisés. Lancement du jeu...";
                _gameLauncherService.LancerJeu();
                TxtStatut.Text = "Jeu lancé !";
            }
            catch (Exception ex)
            {
                TxtStatut.Text = $"Erreur : {ex.Message}";
            }
            finally
            {
                BtnLancerJeu.IsEnabled = true;
                ConteneurBarreProgression.Visibility = Visibility.Collapsed;
            }
        }

        private void BtnSteamWorkshop_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_settings.UrlSteamWorkshop))
            {
                TxtStatut.Text = "Aucun lien Steam Workshop configuré (voir appsettings.json).";
                return;
            }

            Process.Start(new ProcessStartInfo(_settings.UrlSteamWorkshop) { UseShellExecute = true });
        }
    }

    /// <summary>
    /// Chargement des paramètres depuis appsettings.json
    /// (chemins et URLs, à adapter une fois l'hébergement des mods choisi).
    /// </summary>
    public class AppSettings
    {
        public string DossierMods { get; set; } = string.Empty;
        public string CheminConfigCfg { get; set; } = string.Empty;
        public string CheminExeJeu { get; set; } = string.Empty;
        public string UrlManifest { get; set; } = string.Empty;
        public string UrlArchiveComplete { get; set; } = string.Empty;
        public string UrlSteamWorkshop { get; set; } = string.Empty;
        public string ServeurIp { get; set; } = string.Empty;
        public int ServeurPortQuery { get; set; } = 27016;

        public static AppSettings Charger()
        {
            string chemin = Path.Combine(AppContext.BaseDirectory, "appsettings.json");

            if (!File.Exists(chemin))
                return new AppSettings();

            string json = File.ReadAllText(chemin);
            var settings = JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();

            // Résout les variables d'environnement type %USERPROFILE% dans les chemins
            settings.DossierMods = Environment.ExpandEnvironmentVariables(settings.DossierMods);
            settings.CheminConfigCfg = Environment.ExpandEnvironmentVariables(settings.CheminConfigCfg);
            settings.CheminExeJeu = Environment.ExpandEnvironmentVariables(settings.CheminExeJeu);

            return settings;
        }
    }
}
