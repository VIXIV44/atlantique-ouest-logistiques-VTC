using System.Windows.Controls;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public partial class OrdreModView : UserControl
    {
        public OrdreModView()
        {
            InitializeComponent();
        }
    }
}
