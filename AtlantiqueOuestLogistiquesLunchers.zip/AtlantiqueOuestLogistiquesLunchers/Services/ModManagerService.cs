using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading.Tasks;
using AtlantiqueOuestLogistiquesLunchers.Models;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    /// <summary>
    /// Scanne le dossier de mods du joueur, compare avec un manifest distant,
    /// télécharge les mods manquants ou remplace l'intégralité par une archive complète.
    /// </summary>
    public class ModManagerService
    {
        private readonly string _dossierMods;
        private readonly string _urlManifest;
        private readonly string _urlArchiveComplete;
        private readonly HttpClient _client;

        // Si le nombre de mods manquants dépasse ce seuil,
        // on retélécharge l'archive complète plutôt que fichier par fichier.
        public int SeuilArchiveComplete { get; set; } = 5;

        public ModManagerService(string dossierMods, string urlManifest, string urlArchiveComplete)
        {
            _dossierMods = dossierMods;
            _urlManifest = urlManifest;
            _urlArchiveComplete = urlArchiveComplete;

            // Les archives de mods (ProMods + add-ons) peuvent faire plusieurs
            // gigaoctets : le timeout par défaut de HttpClient (100 secondes)
            // est bien trop court et provoquerait un échec silencieux en
            // pleine téléchargement. On l'étend largement.
            _client = new HttpClient { Timeout = TimeSpan.FromHours(3) };
        }

        public async Task<List<ModManifestEntry>> TelechargerManifestAsync()
        {
            string json = await _client.GetStringAsync(_urlManifest);
            return JsonSerializer.Deserialize<List<ModManifestEntry>>(json) ?? new List<ModManifestEntry>();
        }

        public async Task<List<ModManifestEntry>> ScannerModsManquantsAsync()
        {
            var manifest = await TelechargerManifestAsync();
            var manquants = new List<ModManifestEntry>();

            Directory.CreateDirectory(_dossierMods);

            foreach (var mod in manifest)
            {
                string chemin = Path.Combine(_dossierMods, mod.NomFichier);

                if (!File.Exists(chemin))
                {
                    manquants.Add(mod);
                    continue;
                }

                if (!string.IsNullOrEmpty(mod.HashAttendu) && CalculerHash(chemin) != mod.HashAttendu)
                    manquants.Add(mod);
            }

            return manquants;
        }

        /// <summary>
        /// Décide automatiquement : téléchargement ciblé si peu de mods manquent,
        /// sinon remplacement complet via l'archive.
        /// </summary>
        public async Task SynchroniserModsAsync(List<ModManifestEntry> manquants, IProgress<EtatTelechargement>? progression = null)
        {
            if (manquants.Count == 0)
            {
                progression?.Report(new EtatTelechargement { Message = "Tous les mods sont déjà à jour.", Pourcentage = 100 });
                return;
            }

            if (manquants.Count <= SeuilArchiveComplete)
                await TelechargerModsManquantsAsync(manquants, progression);
            else
                await RemplacerParArchiveCompleteAsync(progression);
        }

        public async Task TelechargerModsManquantsAsync(List<ModManifestEntry> manquants, IProgress<EtatTelechargement>? progression = null)
        {
            Directory.CreateDirectory(_dossierMods);

            for (int i = 0; i < manquants.Count; i++)
            {
                var mod = manquants[i];
                string prefixe = $"Mod {i + 1}/{manquants.Count} — {mod.NomFichier}";
                await TelechargerVersFichierAsync(mod.UrlTelechargement, Path.Combine(_dossierMods, mod.NomFichier), progression, prefixe);
            }

            progression?.Report(new EtatTelechargement { Message = "Mods manquants installés.", Pourcentage = 100 });
        }

        public async Task RemplacerParArchiveCompleteAsync(IProgress<EtatTelechargement>? progression = null)
        {
            string zipTemp = Path.Combine(Path.GetTempPath(), $"aol_mods_{Guid.NewGuid():N}.zip");

            try
            {
                await TelechargerVersFichierAsync(_urlArchiveComplete, zipTemp, progression, "Téléchargement de l'archive");

                progression?.Report(new EtatTelechargement { Message = "Suppression des anciens mods...", Pourcentage = null });
                if (Directory.Exists(_dossierMods))
                {
                    foreach (var fichier in Directory.GetFiles(_dossierMods))
                        File.Delete(fichier);
                }
                else
                {
                    Directory.CreateDirectory(_dossierMods);
                }

                ExtraireAvecProgression(zipTemp, _dossierMods, progression);

                await EnregistrerSignatureArchiveAsync();

                progression?.Report(new EtatTelechargement { Message = "Mods à jour.", Pourcentage = 100 });
            }
            finally
            {
                // Suppression du zip après dézippage, quoi qu'il arrive
                if (File.Exists(zipTemp))
                    File.Delete(zipTemp);
            }
        }

        /// <summary>
        /// Vérifie si les mods sont déjà à jour, sans rien télécharger :
        /// - le dossier de mods doit déjà contenir des fichiers
        /// - la signature de l'archive distante (ETag / Last-Modified / taille)
        ///   doit être identique à celle enregistrée lors du dernier téléchargement
        /// Évite aux joueurs de retélécharger l'archive à chaque lancement.
        /// </summary>
        public async Task<bool> ModsDejaAJourAsync()
        {
            if (!Directory.Exists(_dossierMods) || Directory.GetFiles(_dossierMods).Length == 0)
                return false;

            string cheminEtat = CheminFichierEtat();
            if (!File.Exists(cheminEtat))
            {
                // Pas d'historique de synchronisation, mais des mods sont déjà
                // présents dans le dossier (installés manuellement ou par une
                // version précédente du launcher) : on les accepte tels quels
                // et on enregistre leur empreinte pour les prochaines vérifications,
                // plutôt que de forcer un téléchargement inutile.
                await EnregistrerSignatureArchiveAsync();
                return true;
            }

            string? signatureEnregistree = await File.ReadAllTextAsync(cheminEtat);
            string? signatureActuelle = await ObtenirSignatureArchiveAsync();

            // Si on n'arrive pas à obtenir de signature distante (serveur qui ne
            // répond pas aux HEAD/Range), on ne bloque pas le joueur : on considère
            // que c'est à jour plutôt que de retélécharger inutilement à chaque fois.
            if (signatureActuelle == null)
                return true;

            return signatureActuelle == signatureEnregistree;
        }

        private async Task EnregistrerSignatureArchiveAsync()
        {
            string? signature = await ObtenirSignatureArchiveAsync();
            if (signature != null)
                await File.WriteAllTextAsync(CheminFichierEtat(), signature);
        }

        private static string CheminFichierEtat() =>
            Path.Combine(AppContext.BaseDirectory, "mods_sync_state.json");

        /// <summary>
        /// Récupère une "empreinte" de l'archive distante (ETag, sinon
        /// Last-Modified + taille) sans télécharger le fichier complet.
        /// </summary>
        private async Task<string?> ObtenirSignatureArchiveAsync()
        {
            try
            {
                using var requete = new HttpRequestMessage(HttpMethod.Head, _urlArchiveComplete);
                using var reponse = await _client.SendAsync(requete);

                if (reponse.IsSuccessStatusCode)
                    return ExtraireSignature(reponse);
            }
            catch { /* on tente le fallback ci-dessous */ }

            try
            {
                // Certains hébergeurs (dont archive.org) refusent parfois HEAD :
                // on retente avec une requête GET ne demandant qu'un seul octet.
                using var requete = new HttpRequestMessage(HttpMethod.Get, _urlArchiveComplete);
                requete.Headers.Range = new System.Net.Http.Headers.RangeHeaderValue(0, 0);
                using var reponse = await _client.SendAsync(requete, HttpCompletionOption.ResponseHeadersRead);

                if (reponse.IsSuccessStatusCode)
                    return ExtraireSignature(reponse);
            }
            catch { /* signature indisponible */ }

            return null;
        }

        private static string ExtraireSignature(HttpResponseMessage reponse)
        {
            string? etag = reponse.Headers.ETag?.Tag;
            if (!string.IsNullOrEmpty(etag))
                return $"etag:{etag}";

            string? derniereModif = reponse.Content.Headers.LastModified?.ToString();
            long? taille = reponse.Content.Headers.ContentRange?.Length ?? reponse.Content.Headers.ContentLength;

            return $"lm:{derniereModif}|taille:{taille}";
        }

        /// <summary>
        /// Télécharge en flux directement vers un fichier (jamais de byte[]
        /// intermédiaire, ce qui évitait déjà un bug avec les en-têtes
        /// Content-Length incohérents d'archive.org), en publiant la
        /// progression (Mo téléchargés / pourcentage) au fil de l'eau.
        /// </summary>
        private async Task TelechargerVersFichierAsync(string url, string cheminDestination,
            IProgress<EtatTelechargement>? progression, string libelle)
        {
            using var reponse = await _client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
            reponse.EnsureSuccessStatusCode();

            long? tailleTotale = reponse.Content.Headers.ContentLength;

            using var streamEntree = await reponse.Content.ReadAsStreamAsync();
            using var streamSortie = new FileStream(cheminDestination, FileMode.Create, FileAccess.Write);

            var tampon = new byte[81920];
            long totalLu = 0;
            int lu;
            DateTime dernierRapport = DateTime.MinValue;

            progression?.Report(new EtatTelechargement { Message = $"{libelle} : démarrage...", Pourcentage = tailleTotale.HasValue ? 0 : null });

            while ((lu = await streamEntree.ReadAsync(tampon)) > 0)
            {
                await streamSortie.WriteAsync(tampon.AsMemory(0, lu));
                totalLu += lu;

                // Limite la fréquence de mise à jour de l'UI (~5x/seconde max)
                if ((DateTime.UtcNow - dernierRapport).TotalMilliseconds < 200)
                    continue;
                dernierRapport = DateTime.UtcNow;

                double mo = totalLu / 1024.0 / 1024.0;

                if (tailleTotale.HasValue && tailleTotale.Value > 0)
                {
                    double pourcentage = Math.Min(100, totalLu * 100.0 / tailleTotale.Value);
                    double totalMo = tailleTotale.Value / 1024.0 / 1024.0;
                    progression?.Report(new EtatTelechargement
                    {
                        Message = $"{libelle} : {mo:0.0} Mo / {totalMo:0.0} Mo ({pourcentage:0}%)",
                        Pourcentage = pourcentage
                    });
                }
                else
                {
                    progression?.Report(new EtatTelechargement
                    {
                        Message = $"{libelle} : {mo:0.0} Mo téléchargés...",
                        Pourcentage = null
                    });
                }
            }

            progression?.Report(new EtatTelechargement { Message = $"{libelle} : terminé.", Pourcentage = 100 });
        }

        /// <summary>
        /// Extrait le zip fichier par fichier (plutôt que ZipFile.ExtractToDirectory
        /// en un bloc) pour pouvoir publier une progression en pourcentage.
        /// </summary>
        private static void ExtraireAvecProgression(string cheminZip, string dossierDestination,
            IProgress<EtatTelechargement>? progression)
        {
            using var archive = ZipFile.OpenRead(cheminZip);
            int total = archive.Entries.Count;
            int fait = 0;

            foreach (var entree in archive.Entries)
            {
                string cheminCible = Path.Combine(dossierDestination, entree.FullName);
                string? dossierParent = Path.GetDirectoryName(cheminCible);

                if (!string.IsNullOrEmpty(dossierParent))
                    Directory.CreateDirectory(dossierParent);

                bool estUnDossier = entree.FullName.EndsWith("/") || entree.FullName.EndsWith("\\");
                if (!estUnDossier)
                    entree.ExtractToFile(cheminCible, overwrite: true);

                fait++;
                double pourcentage = total > 0 ? fait * 100.0 / total : 100;
                progression?.Report(new EtatTelechargement
                {
                    Message = $"Extraction : {fait}/{total} fichiers ({pourcentage:0}%)",
                    Pourcentage = pourcentage
                });
            }
        }

        private static string CalculerHash(string chemin)
        {
            using var sha256 = SHA256.Create();
            using var stream = File.OpenRead(chemin);
            return Convert.ToHexString(sha256.ComputeHash(stream));
        }
    }
}
