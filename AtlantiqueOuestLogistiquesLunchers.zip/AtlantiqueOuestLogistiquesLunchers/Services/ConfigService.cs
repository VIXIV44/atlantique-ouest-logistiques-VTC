using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    /// <summary>
    /// Modifie le fichier config.cfg d'Euro Truck Simulator 2
    /// (convoy size et buffer size).
    /// </summary>
    public class ConfigService
    {
        private readonly string _configPath;

        public ConfigService(string configPath)
        {
            _configPath = configPath;
        }

        public void AppliquerParametres()
        {
            if (!File.Exists(_configPath))
                throw new FileNotFoundException(
                    $"config.cfg introuvable à l'emplacement : {_configPath}. " +
                    "Lance le jeu au moins une fois pour qu'il soit généré.", _configPath);

            var lignes = File.ReadAllLines(_configPath).ToList();

            RemplacerOuAjouter(lignes, "g_convoy_size", "uset g_convoy_size \"128\"");
            RemplacerOuAjouter(lignes, "g_buffer_size", "uset g_buffer_size \"70\"");

            File.WriteAllLines(_configPath, lignes);
        }

        private static void RemplacerOuAjouter(List<string> lignes, string cle, string nouvelleLigne)
        {
            // NOTE : vérifie les noms exacts des clés dans ton propre config.cfg
            // (ouvre-le avec le Bloc-notes et cherche "convoy" / "buffer").
            // Certaines versions du jeu utilisent des noms légèrement différents.
            int index = lignes.FindIndex(l => Regex.IsMatch(l.Trim(), $@"^uset\s+{Regex.Escape(cle)}\b"));

            if (index >= 0)
                lignes[index] = nouvelleLigne;
            else
                lignes.Add(nouvelleLigne);
        }
    }
}
