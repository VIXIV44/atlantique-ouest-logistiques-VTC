using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using AtlantiqueOuestLogistiquesLunchers.Views;

namespace AtlantiqueOuestLogistiquesLunchers
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            GenererChampEtoiles();
            ZoneContenu.Content = new LancementTelechargementView();
            MettreEnSurbrillance(BtnLancement);
        }

        /// <summary>
        /// Génère un champ d'étoiles statique sur un canevas virtuel de taille fixe.
        /// Le Viewbox parent (Stretch="Fill") s'occupe de l'étirer pour couvrir toute
        /// la fenêtre, y compris en plein écran/maximisé — pas besoin de régénérer
        /// les étoiles au redimensionnement.
        /// </summary>
        private void GenererChampEtoiles()
        {
            var alea = new Random(42);
            var couleurs = new[] { Colors.White, Colors.White, Colors.White, (Color)ColorConverter.ConvertFromString("#22D3EE") };

            for (int i = 0; i < 220; i++)
            {
                double taille = alea.NextDouble() switch
                {
                    < 0.75 => alea.Next(1, 2),
                    < 0.95 => alea.Next(2, 3),
                    _ => alea.Next(3, 4)
                };

                var etoile = new Ellipse
                {
                    Width = taille,
                    Height = taille,
                    Fill = new SolidColorBrush(couleurs[alea.Next(couleurs.Length)]),
                    Opacity = 0.25 + alea.NextDouble() * 0.65
                };

                Canvas.SetLeft(etoile, alea.NextDouble() * CanvasEtoiles.Width);
                Canvas.SetTop(etoile, alea.NextDouble() * CanvasEtoiles.Height);
                CanvasEtoiles.Children.Add(etoile);
            }
        }

        private void Naviguer_Click(object sender, RoutedEventArgs e)
        {
            var bouton = (Button)sender;

            if (bouton == BtnLancement)
                ZoneContenu.Content = new LancementTelechargementView();
            else if (bouton == BtnOrdreMod)
                ZoneContenu.Content = new OrdreModView();
            else if (bouton == BtnCarte)
                ZoneContenu.Content = new CarteInteractiveView();
            else if (bouton == BtnHistoire)
                ZoneContenu.Content = new NotreHistoireView();
            else if (bouton == BtnConseils)
                ZoneContenu.Content = new ConseilAidesView();

            MettreEnSurbrillance(bouton);
        }

        private void MettreEnSurbrillance(Button boutonActif)
        {
            var boutonMenu = (Style)FindResource("BoutonMenu");
            var boutonMenuActif = (Style)FindResource("BoutonMenuActif");

            foreach (var bouton in new[] { BtnLancement, BtnCarte, BtnOrdreMod, BtnHistoire, BtnConseils })
                bouton.Style = (bouton == boutonActif) ? boutonMenuActif : boutonMenu;
        }
    }
}
